Single Sign On for phpBB 3.3.5+
====================

An installation guide is available here:
http://docs.oneall.com/plugins/guide/single-sign-on-phpbb/3.3.5/