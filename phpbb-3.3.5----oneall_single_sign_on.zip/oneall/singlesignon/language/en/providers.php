<?php
/**
 * @package       OneAll Single Sign On
 * @copyright     Copyright 2011-Present http://www.oneall.com
 * @license       GPL-2.0
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,USA.
 *
 * The "GNU General Public License" (GPL) is available at
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 */

/**
 * English translations by OneAll
 * http://www.oneall.com
 */
if (!defined('IN_PHPBB'))
{
    exit();
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

// Single Sign On Providers.
$lang = array_merge($lang, array(
    'OA_SINGLE_SIGN_ON_P_AMAZON' => 'Amazon',
    'OA_SINGLE_SIGN_ON_P_APPLE' => 'Apple',
    'OA_SINGLE_SIGN_ON_P_BATTLENET' => 'Battle.net',
    'OA_SINGLE_SIGN_ON_P_BLOGGER' => 'Blogger',
    'OA_SINGLE_SIGN_ON_P_STORAGE' => 'Cloud Storage',
    'OA_SINGLE_SIGN_ON_P_DISCORD' => 'Discord',
    'OA_SINGLE_SIGN_ON_P_DISQUS' => 'Disqus',
    'OA_SINGLE_SIGN_ON_P_DRAUGIEM' => 'Draugiem',
    'OA_SINGLE_SIGN_ON_P_DRIBBBLE' => 'Dribbble',
    'OA_SINGLE_SIGN_ON_P_FACEBOOK' => 'Facebook',
    'OA_SINGLE_SIGN_ON_P_FOURSQUARE' => 'Foursquare',
    'OA_SINGLE_SIGN_ON_P_GITHUBCOM' => 'Github.com',
    'OA_SINGLE_SIGN_ON_P_GOOGLE' => 'Google',
    'OA_SINGLE_SIGN_ON_P_INSTAGRAM' => 'Instagram',
    'OA_SINGLE_SIGN_ON_P_LINE' => 'Line',
    'OA_SINGLE_SIGN_ON_P_LINKEDIN' => 'LinkedIn',
    'OA_SINGLE_SIGN_ON_P_LIVEJOURNAL' => 'LiveJournal',
    'OA_SINGLE_SIGN_ON_P_MAILRU' => 'Mail.ru',
    'OA_SINGLE_SIGN_ON_P_MIXER' => 'Mixer',
    'OA_SINGLE_SIGN_ON_P_MEETUP' => 'Meetup',
    'OA_SINGLE_SIGN_ON_P_ODNOKLASSNIKI' => 'Odnoklassniki',
    'OA_SINGLE_SIGN_ON_P_OPENID' => 'OpenID',
    'OA_SINGLE_SIGN_ON_P_PATREON' => 'Patreon',
    'OA_SINGLE_SIGN_ON_P_PAYPAL' => 'PayPal',
    'OA_SINGLE_SIGN_ON_P_PINTEREST' => 'Pinterest',
    'OA_SINGLE_SIGN_ON_P_PIXELPIN' => 'PixelPin',
    'OA_SINGLE_SIGN_ON_P_REDDIT' => 'Reddit',
    'OA_SINGLE_SIGN_ON_P_SKYROCKCOM' => 'Skyrock.com',
    'OA_SINGLE_SIGN_ON_P_SOUNDCLOUD' => 'SoundCloud',
    'OA_SINGLE_SIGN_ON_P_STACKEXCHANGE' => 'StackExchange',
    'OA_SINGLE_SIGN_ON_P_STEAM' => 'Steam',
    'OA_SINGLE_SIGN_ON_P_TUMBLR' => 'Tumblr',
    'OA_SINGLE_SIGN_ON_P_TWITCHTV' => 'Twitch.tv',
    'OA_SINGLE_SIGN_ON_P_TWITTER' => 'Twitter',
    'OA_SINGLE_SIGN_ON_P_VIMEO' => 'Vimeo',
    'OA_SINGLE_SIGN_ON_P_VKONTAKTE' => 'VKontakte',
    'OA_SINGLE_SIGN_ON_P_WEIBO' => 'Weibo',
    'OA_SINGLE_SIGN_ON_P_WINDOWSLIVE' => 'Windows Live',
    'OA_SINGLE_SIGN_ON_P_WORDPRESSCOM' => 'WordPress.com',
    'OA_SINGLE_SIGN_ON_P_XING' => 'XING',
    'OA_SINGLE_SIGN_ON_P_YAHOO' => 'Yahoo',
    'OA_SINGLE_SIGN_ON_P_YOUTUBE' => 'YouTube'
));
